declare const global: any;
