interface Window {
  SockJS: any;
}
