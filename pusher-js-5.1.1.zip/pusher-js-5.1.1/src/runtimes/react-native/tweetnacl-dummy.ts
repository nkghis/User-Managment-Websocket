export default {
  secretbox: {},
  randomBytes: {}
};
