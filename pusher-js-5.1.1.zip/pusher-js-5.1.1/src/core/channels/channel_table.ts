import Channel from './channel';

interface ChannelTable {
  [index: string]: Channel;
}

export default ChannelTable;
