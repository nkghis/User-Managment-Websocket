interface ScriptReceiver {
    number: number;
    id: string;
    name: string;
    callback: Function;
}
export default ScriptReceiver;
