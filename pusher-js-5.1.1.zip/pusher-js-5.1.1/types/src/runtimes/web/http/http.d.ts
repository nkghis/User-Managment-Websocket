import HTTP from 'isomorphic/http/http';
export default HTTP;
