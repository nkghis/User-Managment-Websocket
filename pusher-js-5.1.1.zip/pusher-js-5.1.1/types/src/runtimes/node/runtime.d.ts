import Runtime from '../interface';
declare const NodeJS: Runtime;
export default NodeJS;
