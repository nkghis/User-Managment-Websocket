import Runtime from '../interface';
declare const Worker: Runtime;
export default Worker;
