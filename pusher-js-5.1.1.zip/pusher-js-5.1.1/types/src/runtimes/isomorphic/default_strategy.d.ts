import Strategy from 'core/strategies/strategy';
declare var getDefaultStrategy: (config: any, defineTransport: Function) => Strategy;
export default getDefaultStrategy;
