declare enum State {
    CONNECTING = 0,
    OPEN = 1,
    CLOSED = 3
}
export default State;
